//
//  viewhprofileViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/25/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class viewhprofileViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    let arr:[String] = ["Home","About","Doctors","Departments","Contact Us"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        cell.accessoryType = .detailButton
        return cell
        
    }
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
      print("ok")
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        
        if indexPath.row == 0 {
            
            let alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
       
        }
        if indexPath.row == 1 {
            let alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            
            
        }
        if indexPath.row == 2 {
            let alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            
            
        }
        if indexPath.row == 3 {
            
            let alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            
        }
        if indexPath.row == 4 {
            
            let alt = UIAlertController(title: arr[indexPath.row], message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
            
        }
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
