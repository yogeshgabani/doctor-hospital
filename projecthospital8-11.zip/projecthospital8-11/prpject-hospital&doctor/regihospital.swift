//
//  regihospital.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class regihospital: NSObject {

    var hospital_id:Int?
    var hospital_name:String?
    var address:String?
    var city:String?
    var website:String?
    var contact_no:String
    var imgpath:String?
    
    
    init(hospital_id1:Int,hospital_name1:String,address1:String,city1:String,website1:String,contact_no1:String,imgpath1:String) {
        
        self.hospital_id = hospital_id1
        self.hospital_name = hospital_name1
        self.address = address1
        self.city = city1
        self.website = website1
        self.contact_no = contact_no1
        self.imgpath = imgpath1
        
    }
    
    
    
    
    
    
    
    
}
