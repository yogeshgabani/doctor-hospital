//
//  hospitalViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/24/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit
let REGEX_USER_NAME_LIMIT = "^.{3,10}$"
let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}"
let REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
let REGEX_PASSWORD_LIMIT = "^.{6,20}$"
let REGEX_PASSWORD  = "[A-Za-z0-9]{6,20}"
let REGEX_PHONE_DEFAULT = "[0-9]{10}"

class hospitalViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,registrationhospitaledelegate {

    
    let imgpicker = UIImagePickerController()
    
    
    @IBOutlet weak var txthname: TextFieldValidator!
    
    @IBOutlet weak var txtaddress: UITextField!
    
    @IBOutlet weak var txtcity: UITextField!
    
    
    @IBOutlet weak var txtwebsite: UITextField!
    
    
    @IBOutlet weak var txtcon: TextFieldValidator!
    
    
    
    @IBOutlet weak var imgview: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setvalidation()
         
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)

        
        self.view.backgroundColor = UIColor.white
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handle))
        tap.numberOfTapsRequired = 1
        imgview.isUserInteractionEnabled = true
        imgview.addGestureRecognizer(tap)
        
        imgview.layer.cornerRadius = imgview.frame.size.width/2
        imgview.clipsToBounds = true

       // navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    
    func strreturn(str: String) {
        print(str)
    }
    func handle(sender: UITapGestureRecognizer)  {
        
        imgpicker.sourceType = .photoLibrary
        imgpicker.delegate = self
        self.present(imgpicker, animated: true, completion: nil)
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        imgview.image = img1
        self.dismiss(animated: true, completion: nil)
        
    }

    func setvalidation() {
       
        txthname.addRegx(REGEX_USER_NAME, withMsg: "Enter 3 to 10 char")
        txthname.presentInView = self.view
        txtcon.addRegx(REGEX_PHONE_DEFAULT, withMsg: "Enter contact number")
        txtcon.presentInView = self.view
        
        
    }
    
    @IBAction func btnsubmit(_ sender: Any) {
        
        let img1 = imgview.image
        let imgdata = UIImageJPEGRepresentation(img1!, 1.0)
        let base64string = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let obj = regihospital(hospital_id1: 0, hospital_name1: txthname.text!, address1: txtaddress.text!, city1: txtcity.text!, website1: txtwebsite.text!, contact_no1: txtcon.text!, imgpath1: base64string!)
        let regiobj = regihospitalcontroller()
        regiobj.delegate = self
        regiobj.registrationdetails(obj: obj, url: "http://localhost/pro/regi_hos.php")
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
