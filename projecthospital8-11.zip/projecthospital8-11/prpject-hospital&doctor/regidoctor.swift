//
//  regidoctor.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class regidoctor: NSObject {

    var doctor_id:Int?
    var doctor_name:String?
    var doc_qua:String?
    var doc_spea:String?
    var city:String?
    var password:String
    var imgpath:String?
    
    
    init(doctor_id1:Int,doctor_name1:String,doc_qua1:String,doc_spea1:String,city1:String,password1:String,imgpath1:String) {
        
        self.doctor_id = doctor_id1
        self.doctor_name = doctor_name1
        self.doc_qua = doc_qua1
        self.doc_spea = doc_spea1
        self.city = city1
        self.password = password1
        self.imgpath = imgpath1
}
}
