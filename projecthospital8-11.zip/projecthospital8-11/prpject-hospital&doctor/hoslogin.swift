//
//  hoslogin.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit


@objc protocol logindelegate {
    @objc optional func strreturn(str: [Any])
}

@objc protocol logindocdelegate {
     @objc optional func strreturn1(str1:[Any]);
}
class hoslogin: NSObject {
    
    var delegate:logindelegate?
    func logindetails(obj: loginhospital, url: String ) {
        
            let test = "http://localhost/pro/select_hosp.php"
            
            let strbody = "hospital_name=\(obj.hospital_name!)&contact_no=\(obj.contact_no!)"
            let url = URL(string: test)
            var request = URLRequest(url: url!)
            request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = strbody.data(using: String.Encoding.utf8)
            request.httpMethod = "POST"
            let session = URLSession.shared;
            let datatask = session.dataTask(with: request, completionHandler: {(data2, resp, err) in
                
                DispatchQueue.main.async {
                    do
                    {
                        
                        let str1 = String(data: data2!, encoding: String.Encoding.utf8)
                        print(str1 ?? "ok")
                        let jasondata = try JSONSerialization.jsonObject(with: data2!, options: []) as! [[String:String]]
                        self.delegate?.strreturn!(str: jasondata)
                        
                        
                    }
                    catch
                    {
                    }
                    
                }
            })
            datatask.resume()
        
    }
    
}
class doclogin: NSObject {
    
    var delegate:logindocdelegate?
    func logindetails(obj: logindoctor1, url: String ) {
        
        let test = "http://localhost/pro/select_doc.php"
        
        let strbody = "doctor_name=\(obj.doctor_name!)&password=\(obj.password!)"
        let url = URL(string: test)
        var request = URLRequest(url: url!)
        request.addValue(String(strbody.characters.count), forHTTPHeaderField: "Content-Length")
        request.httpBody = strbody.data(using: String.Encoding.utf8)
        request.httpMethod = "POST"
        let session = URLSession.shared;
        let datatask = session.dataTask(with: request, completionHandler: {(data2, resp, err) in
            
            DispatchQueue.main.async {
                do
                {
                    
                    let str1 = String(data: data2!, encoding: String.Encoding.utf8)
                    print(str1 ?? "ok")
                    let jasondata = try JSONSerialization.jsonObject(with: data2!, options: []) as! [[String:String]]
                    self.delegate?.strreturn1!(str1: jasondata)
                    
                    
                }
                catch
                {
                }
                
            }
        })
        datatask.resume()
        
    }
    
}
