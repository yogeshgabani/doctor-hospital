//
//  afterhospital.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/25/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class afterhospital: UIViewController,UITableViewDelegate,UITableViewDataSource {

    let hospital :[String] = ["Add Profile","Add Facility","Add Doctors"]
    var str = ""
    
    @IBOutlet weak var lbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let user = UserDefaults()
        let username = user.value(forKey: "hospital_name")
        str = username as! String
        lbl.text = str
        
        /*
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)
       
     
*/
        //navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    
   
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return hospital.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = hospital[indexPath.row]
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            
            let f1 = storyboard?.instantiateViewController(withIdentifier: "viewh") as! viewhprofileViewController
            self.navigationController?.pushViewController(f1, animated: true)
            
        }
        if indexPath.row == 1 {
          //  let f1 = storyboard?.instantiateViewController(withIdentifier: "doctor") as! doctorViewController
           // self.navigationController?.pushViewController(f1, animated: true)
            
        }
        
        
        if indexPath.row == 2 {
            let f1 = storyboard?.instantiateViewController(withIdentifier: "doctor") as! doctorViewController
            self.navigationController?.pushViewController(f1, animated: true)
            
        }
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

class custcell: UITableViewCell {
    
    @IBOutlet weak var addd: UIButton!
}
