//
//  loginhospitalViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/24/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class loginhospitalViewController: UIViewController,logindelegate {

    var arr:[Any] = []
    
    @IBOutlet weak var txtcontact: UITextField!
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var txt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
      
                   /*
        else{
            let f1 = self.storyboard?.instantiateViewController(withIdentifier: "hos") as! loginhospitalViewController
            self.navigationController?.pushViewController(f1, animated: true)
        }*/

        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)

        //navigationController?.navigationBar.isHidden = true
       // let dif = UserDefaults()
       // dif.set("7", forKey: "hospital_id")
        
        
        

        // Do any additional setup after loading the view.
    }
    func strreturn(str: [Any]) {
        print(str)
        let dif = UserDefaults()
        dif.set("1", forKey: "Login")
        dif.set("2", forKey: "hospital_id")
        
        if str.count == 1
        {
            
            
            let alt = UIAlertController(title: "LOGIN", message: "SUCCESFULL", preferredStyle: .alert);
            
            let ok = UIAlertAction(title: "Ok", style: .default, handler: { action in
                
                let f1 = self.storyboard?.instantiateViewController(withIdentifier: "afterh") as! afterhospital
                
                let dif = UserDefaults()
                dif.set("\(self.txt.text!)", forKey: "hospital_name")
                
                self.navigationController?.pushViewController(f1, animated: true)
                
                // self.arr = [];
            })
            
            alt.addAction(ok);
            
            self.present(alt, animated: true, completion: nil);
        }
            
        else
        {
            let alt = UIAlertController(title: "LOGIN", message: "Login Failed", preferredStyle: .alert);
            
            let ok = UIAlertAction(title: "Ok", style: .default, handler: { action in
                // self.arr = [];
            })
            
            alt.addAction(ok);
            
            self.present(alt, animated: true, completion: nil);
        }
        
    }

    @IBAction func btnl(_ sender: Any) {
        let obj = loginhospital(hospital_name1: txt.text!, contact_no1: txtcontact.text!)
        let loginhos = hoslogin()
        loginhos.delegate = self
        loginhos.logindetails(obj: obj, url: "http://localhost/pro/select_hosp.php")
    }
    
    
    
    @IBAction func btnforget(_ sender: Any) {
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
