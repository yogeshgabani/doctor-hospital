//
//  doctorViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/24/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

//let REGEX_USER_NAME_LIMIT = "^.{3,10}$"
//let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}"
//let REGEX_EMAIL  = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
//let REGEX_PASSWORD_LIMIT = "^.{6,20}$"
//let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}"
//let REGEX_PHONE_DEFAULT = "[0-9]{10}"

class doctorViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,registrationdelegate {

    let imgpicker = UIImagePickerController()
    
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var imgview: UIImageView!
    
    @IBOutlet weak var txtdocname: TextFieldValidator!
   
    @IBOutlet weak var txtqua: TextFieldValidator!
    
    @IBOutlet weak var txtspea: TextFieldValidator!
    
    
    @IBOutlet weak var txtcity: TextFieldValidator!
    
    @IBOutlet weak var txtpassword: TextFieldValidator!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setvalidation()
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)

        //navigationController?.navigationBar.isHidden = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handle))
        tap.numberOfTapsRequired = 1
        imgview.isUserInteractionEnabled = true
        imgview.addGestureRecognizer(tap)
        imgview.layer.cornerRadius = imgview.frame.size.width/2
        imgview.clipsToBounds = true
        // Do any additional setup after loading the view.
    }
    func strreturn(str: String) {
        print(str)
    }
    func handle(sender: UITapGestureRecognizer)  {
        
        imgpicker.sourceType = .photoLibrary
        imgpicker.delegate = self
        self.present(imgpicker, animated: true, completion: nil)
        
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        imgview.image = img1
        self.dismiss(animated: true, completion: nil)
        
    }
    func setvalidation() {
       
        txtdocname.addRegx(REGEX_USER_NAME, withMsg: "Enter 3 to 10 char")
        txtdocname.presentInView = self.view
        txtqua.addRegx(REGEX_USER_NAME, withMsg: "Enter Qualification")
        txtqua.presentInView = self.view
        txtspea.addRegx(REGEX_USER_NAME, withMsg: "Enter Spealization")
        txtspea.presentInView = self.view
        txtcity.addRegx(REGEX_USER_NAME, withMsg: "Enter city")
        txtcity.presentInView = self.view
        txtpassword.addRegx(REGEX_PASSWORD, withMsg: "Enter alphanumeric charactors")
        txtpassword.presentInView = self.view
        
    }
    

    @IBAction func btnsubmit(_ sender: Any) {
        
        let img1 = imgview.image
        let imgdata = UIImageJPEGRepresentation(img1!, 1.0)
        let base64string = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let obj = regidoctor(doctor_id1: 0, doctor_name1: txtdocname.text!, doc_qua1: txtqua.text!, doc_spea1: txtspea.text!, city1: txtcity.text!, password1: txtpassword.text!, imgpath1: base64string!)
        let regiobj = regidoctorcontroller()
        regiobj.delegate = self
        regiobj.registrationdetails(obj: obj, url: "http://localhost/pro/regi_doc.php")
        

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
