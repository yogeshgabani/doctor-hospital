//
//  logindoctor.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/24/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class logindoctor: UIViewController,logindocdelegate {

    var arr:[Any] = []
    
    @IBOutlet weak var lbl: UILabel!
    
    @IBOutlet weak var txtdocname: UITextField!
    
    @IBOutlet weak var txtpassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)

        //navigationController?.navigationBar.isHidden = true
        // Do any additional setup after loading the view.
    }
    func strreturn1(str1: [Any]) {
        print(str1)
        let dif = UserDefaults()
        dif.set("1", forKey: "Login")
        
        
        if str1.count == 1
        {
            let alt = UIAlertController(title: "LOGIN", message: "SUCCESFULL", preferredStyle: .alert);
            
            let ok = UIAlertAction(title: "Ok", style: .default, handler: { action in
                
                let f1 = self.storyboard?.instantiateViewController(withIdentifier: "afterdoctor") as! afterdoctorViewController
                let dif = UserDefaults()
                dif.set("\(self.txtdocname.text!)", forKey: "doctor_name")
                
                self.navigationController?.pushViewController(f1, animated: true)
                
                
            })
            
            alt.addAction(ok);
            
            self.present(alt, animated: true, completion: nil);
        }
            
        else
        {
            let alt = UIAlertController(title: "LOGIN", message: "Login Failed", preferredStyle: .alert);
            
            let ok = UIAlertAction(title: "Ok", style: .default, handler: { action in
               
            })
            
            alt.addAction(ok);
            
            self.present(alt, animated: true, completion: nil);
        }
    }
    @IBAction func btnlogin(_ sender: Any) {
        print("btnlogin")
        let obj = logindoctor1(doctor_name1: txtdocname.text!, password1: txtpassword.text!)
        let loginobj = doclogin()
        loginobj.delegate = self
        loginobj.logindetails(obj: obj, url: "http://localhost/pro/select_doc.php")
        
    }
    
    @IBAction func btnforget(_ sender: Any) {
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
