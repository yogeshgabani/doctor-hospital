//
//  loginhospital.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class loginhospital: NSObject {

    var hospital_name: String?
    var contact_no:String?
    
    init(hospital_name1:String,contact_no1:String)
    {
        self.hospital_name  = hospital_name1
        self.contact_no = contact_no1
    }
    
}

class logindoctor1: NSObject {
    
    var doctor_name: String?
    var password:String?
    
    init(doctor_name1:String,password1:String)
    {
        self.doctor_name  = doctor_name1
        self.password = password1
    }

}
