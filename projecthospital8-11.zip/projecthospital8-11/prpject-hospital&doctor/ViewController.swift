//
//  ViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/24/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet var login: UIButton!
    @IBOutlet weak var v1: UIView!
    @IBOutlet weak var seg: UISegmentedControl!
    
        override func viewDidLoad() {
        super.viewDidLoad()
        
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)
            
            
            
 
      
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnlogin(_ sender: Any) {
        
        if seg.selectedSegmentIndex == 0 {
            let f1 = self.storyboard?.instantiateViewController(withIdentifier: "hos") as! loginhospitalViewController
            self.navigationController?.pushViewController(f1, animated: true)

            
            //let dif = UserDefaults()
            
          //  let loginstatus = dif.value(forKey:"Login" ) as! String;
            
          /*  if loginstatus == "1"
                
            {
                let page = self.storyboard?.instantiateViewController(withIdentifier: "afterh") as! afterhospital
                self.navigationController?.pushViewController(page, animated: true)
            }
            else
            {
                let f1 = self.storyboard?.instantiateViewController(withIdentifier: "hos") as! loginhospitalViewController
                self.navigationController?.pushViewController(f1, animated: true)
                
            }*/
            
        }
        else{
            let f2 = self.storyboard?.instantiateViewController(withIdentifier: "doc") as! logindoctor
            self.navigationController?.pushViewController(f2, animated: true)
            

            //let dif = UserDefaults()
            
         //   let loginstatus = dif.value(forKey:"Login" ) as! String;
            
         /*   if loginstatus == "1"
                
            {
                let page = self.storyboard?.instantiateViewController(withIdentifier: "afterdoctor") as! afterdoctorViewController
                self.navigationController?.pushViewController(page, animated: true)
            }
            else
            {
                let f2 = self.storyboard?.instantiateViewController(withIdentifier: "doc") as! logindoctor
                self.navigationController?.pushViewController(f2, animated: true)
                
            }*/
            
        }
    }
    
   
        
    @IBAction func btnregi(_ sender: Any) {
        if seg.selectedSegmentIndex == 0 {
            
            let f1 = self.storyboard?.instantiateViewController(withIdentifier: "hospital") as! hospitalViewController
            self.navigationController?.pushViewController(f1, animated: true)
            
            
            
        }
        else
        {
            let f2 = self.storyboard?.instantiateViewController(withIdentifier: "doctor") as! doctorViewController
            self.navigationController?.pushViewController(f2, animated: true)
            
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

