//
//  custcellCollectionViewCell.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/25/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class custcellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lbl: UILabel!
    
    }
