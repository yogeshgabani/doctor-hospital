//
//  afterdoctorViewController.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 9/27/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

class afterdoctorViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    let arr:[String] = ["Profile","Patients","Reports","Calender"]
    var str = ""
    var str1 = ""
    
    @IBOutlet weak var lbl: UILabel!
    @IBOutlet weak var seg: UISegmentedControl!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
        UIGraphicsBeginImageContext(self.view.frame.size)
        UIImage(named: "back")?.draw(in: self.view.bounds)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        self.view.backgroundColor = UIColor(patternImage: image)
        */
       // navigationController?.navigationBar.isHidden = true
        let user = UserDefaults()
        let username = user.value(forKey: "doctor_name")
        str = username as! String
        lbl.text = str
        
        let hospitalid = user.value(forKey: "hospital_id")
        str1 = hospitalid as! String
        print(str1)
        
        
        // Do any additional setup after loading the view.
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as! custcell1
        cell.lbl.text = arr[indexPath.row]
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            
        }
    }
    
    @IBAction func segment(_ sender: Any) {
        if seg.selectedSegmentIndex == 0 {
            
        }
            }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
class custcell1: UICollectionViewCell {
    
    @IBOutlet weak var lbl: UILabel!
}
