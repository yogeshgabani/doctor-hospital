//
//  regidoctorcontroller.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

@objc protocol registrationdelegate {
   @objc optional func strreturn(str:String)
}
class regidoctorcontroller: NSObject {

    var delegate:registrationdelegate?
    
    func registrationdetails(obj: regidoctor ,url: String) {
        
        var dic:[String: String] = [:];
        
        dic["doctor_name"] = obj.doctor_name
        dic["doc_qua"] = obj.doc_qua
        dic["doc_spea"] = obj.doc_spea
        dic["city"] = obj.city
        dic["password"] = obj.password
        dic["imgpath"] = obj.imgpath
        do {
            let dt = try JSONSerialization.data(withJSONObject: dic, options: [])
            let url1 = URL(string: url)
            var request = URLRequest(url: url1!)
            request.addValue(String(dt.count), forHTTPHeaderField: "Content-Length")
            
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            request.httpBody = dt
            request.httpMethod = "POST";
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler: {(data1, resp, err) in
                
                
                let str = String(data: data1!, encoding: String.Encoding.utf8);
                DispatchQueue.main.async {
                    print(str!);
                    self.delegate?.strreturn!(str: str!)
                    
                }
                
                
            })
            
            
            datatask.resume();
            
            
            
            
        } catch  {
            
        }
    }
    
    
}
