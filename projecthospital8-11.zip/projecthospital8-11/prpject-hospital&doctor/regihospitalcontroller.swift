//
//  regihospitalcontroller.swift
//  prpject-hospital&doctor
//
//  Created by TOPS on 10/6/17.
//  Copyright © 2017 TOPS. All rights reserved.
//

import UIKit

@objc protocol registrationhospitaledelegate {
    @objc optional func strreturn(str: String)
    

}
class regihospitalcontroller: NSObject {

    var delegate:registrationhospitaledelegate?
    
    func registrationdetails(obj: regihospital ,url: String) {
        
        var dic:[String: String] = [:];
        
        dic["hospital_name"] = obj.hospital_name
        dic["address"] = obj.address
        
        dic["city"] = obj.city
        dic["website"] = obj.website
        dic["contact_no"] = obj.contact_no
        dic["imgpath"] = obj.imgpath
        
        do {
            let dt = try JSONSerialization.data(withJSONObject: dic, options: [])
            let url = URL(string: url)
            var request = URLRequest(url: url!)
            request.addValue(String(dt.count), forHTTPHeaderField: "Content-Length")
            
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            request.httpBody = dt
            request.httpMethod = "POST";
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request, completionHandler: {(data1, resp, err) in
                
                
                let str = String(data: data1!, encoding: String.Encoding.utf8);
                DispatchQueue.main.async {
                    print(str!);
                    self.delegate?.strreturn!(str: str!)
                    
                }
                
            })
            
            datatask.resume();
           } catch  {
            
        }
    }
    
    
    
}
